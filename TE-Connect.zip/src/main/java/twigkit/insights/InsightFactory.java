package twigkit.insights;

import twigkit.insights.model.Insight;

public interface InsightFactory {

    Insight insight();

}
