var twigkitHttpHost = 'localhost';
var twigkitHttpPort = '8080';