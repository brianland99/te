/*@ngInject*/
export function SearchController($scope, $stateParams) {
  $scope.params = $stateParams;
}