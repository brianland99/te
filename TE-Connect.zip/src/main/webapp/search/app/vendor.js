import angular from 'angular';
import 'angular-touch';
import 'angular-animate';
import 'angular-cookies';
import 'angular-sanitize';
import 'angular-ui-router';

// import 'appkit-ui/dist/js/lightning.min.js'; // Doesn't work with webpack. For now using wro4j for this.
// import 'appkit-ui/dist/js/lightning.core.min.js'; // Works with webpack. 
// import '../../builder/lib/lightning.core.js'; // Works with webpack. 
